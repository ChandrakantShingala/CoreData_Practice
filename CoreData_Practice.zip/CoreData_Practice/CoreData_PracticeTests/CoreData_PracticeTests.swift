//
//  CoreData_PracticeTests.swift
//  CoreData_PracticeTests
//
//  Created by Chandrakant shingala on 01/01/25.
//

import Testing
@testable import CoreData_Practice

struct CoreData_PracticeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
