//
//  ViewController.swift
//  CoreData_Practice
//
//  Created by Chandrakant shingala on 01/01/25.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtAddress: UITextField!
    @IBOutlet weak var txtCity: UITextField!
    @IBOutlet weak var txtMobileNo: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func saveButtonClick(_ sender: UIButton) {
        let dict = ["name": txtName.text, "address": txtAddress.text, "city": txtCity.text, "mobile": txtMobileNo.text]
        DataBaseHelper.sharedInstant.save(object: dict as! [String: String])
    }
    
    @IBAction func showListButtonClick(_ sender: UIButton) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "StudentListViewController")
        navigationController?.pushViewController(vc, animated: true)
    }
    
}

