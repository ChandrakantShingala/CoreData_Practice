//
//  DataBaseHelper.swift
//  CoreData_Practice
//
//  Created by Chandrakant shingala on 01/01/25.
//

import Foundation
import CoreData
import UIKit

class DataBaseHelper {
    
    static var sharedInstant = DataBaseHelper()
    let context = (UIApplication.shared.delegate as? AppDelegate)?.persistentContainer.viewContext
    
    func save(object: [String: String]) {
        let student = NSEntityDescription.insertNewObject(forEntityName: "Student", into: context!) as! Student
        student.name = object["name"]
        student.address = object["address"]
        student.city = object["city"]
        student.mobile = (object["mobile"])
        do {
            try context?.save()
        } catch {
            print("Error saving data \(error)")
        }
    }
    
    func fetchStudentListData() -> [Student] {
        var student: [Student] = []
        let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Student")
        do {
            student = try context?.fetch(fetchRequest) as! [Student]
        } catch {
            print("Data has not been fetched")
        }
        return student
    }
    
    func deleteStudentData(index: Int) -> [Student] {
        var student = fetchStudentListData()
        context?.delete(student[index])
        student.remove(at: index)
        do {
            try context?.save()
        } catch {
            print("Error deleting data \(error)")
        }
        return student
    }
}
