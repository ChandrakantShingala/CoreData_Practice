//
//  StudentListViewController.swift
//  CoreData_Practice
//
//  Created by Chandrakant shingala on 01/01/25.
//

import UIKit

class StudentListViewController: UIViewController {

    @IBOutlet weak var studentListTableView: UITableView!
    
    var arrStudent = [Student]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        arrStudent = DataBaseHelper.sharedInstant.fetchStudentListData()
    }

}

extension StudentListViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrStudent.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "StudentListTableViewCell", for: indexPath) as! StudentListTableViewCell
        cell.student = arrStudent[indexPath.row]
        return cell
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            arrStudent = DataBaseHelper.sharedInstant.deleteStudentData(index: indexPath.row)
            self.studentListTableView.deleteRows(at: [indexPath], with: .automatic)
            
        }
    }
}
