//
//  StudentListTableViewCell.swift
//  CoreData_Practice
//
//  Created by Chandrakant shingala on 01/01/25.
//

import UIKit

class StudentListTableViewCell: UITableViewCell {

    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var addressLabel: UILabel!
    @IBOutlet weak var cityLabel: UILabel!
    @IBOutlet weak var mobileLabel: UILabel!
    
    var student: Student? {
        didSet {
            guard let student else { return }
            nameLabel.text = "Name :  \(student.name ?? "No Name Found")"
            addressLabel.text = "Address :  \(student.address ?? "No Address Found")"
            cityLabel.text = "City : \(student.city ?? "No City Found")"
            mobileLabel.text = "MobileNo. : \(student.mobile ?? "No Mobile Number Found")"
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
