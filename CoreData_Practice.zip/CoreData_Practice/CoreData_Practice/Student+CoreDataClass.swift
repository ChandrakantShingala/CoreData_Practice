//
//  Student+CoreDataClass.swift
//  CoreData_Practice
//
//  Created by Chandrakant shingala on 01/01/25.
//
//

import Foundation
import CoreData

@objc(Student)
public class Student: NSManagedObject {

}
